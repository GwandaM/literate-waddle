# Investment Performance Interpreter

A tool that doesn't just say "your portfolio returned 8%" — it explains **why** it returned 8%, by connecting the dots between market conditions, portfolio composition, economic factors, and investor behaviour.

## Project Overview

The Performance Interpreter takes four data pillars as input:

1. **Market/Performance Data** — what actually happened to prices and returns
2. **Portfolio-Specific Info** — what's in the portfolio and how it's structured
3. **Macro & Micro Economic Factors** — the external environment
4. **Investor Actions** — what the investor did (cash flows, switches, etc.)

It then defines correlations and interactions between them to generate a plain-English **performance narrative** explaining the drivers of returns.

## Repository Contents

```
├── README.md
├── docs/
│   ├── brainstorm-notes.md          # Full brainstorm of metrics, correlations & interactions
│   └── conversation-transcript.txt  # Raw conversation output from design session
├── src/
│   ├── data-model.mermaid           # Entity-relationship diagram (16 tables, 24 relationships)
│   └── performance-interpreter-demo.jsx  # Interactive React demo (3 views)
```

## Demo Views

The interactive demo (`src/performance-interpreter-demo.jsx`) contains:

| View | Purpose |
|------|---------|
| **Portfolio → Developer View** | Internal pipeline showing all inputs, computed metrics, attribution waterfall, factor sensitivities, and behavioural analysis for a sample SA balanced fund |
| **Portfolio → Investor View** | Clean client-facing report with expandable drivers, timing impact, economic context, and full narrative |
| **Fund Analysis → Developer View** | Allan Gray-Orbis Global Equity Feeder Fund decomposition — top holdings, sector/regional allocation, macro drivers, micro events, factor sensitivities, risk metrics |
| **Fund Analysis → Fund Report** | Polished fund commentary with stock stories, market environment, valuation outlook |

## Data Model

The Mermaid ER diagram covers 16 entities:

- **Core**: Portfolio, Holdings, Instrument, Benchmark
- **Returns**: Market Returns, Portfolio Returns, Benchmark Returns
- **Environment**: Macro Factors, Micro Factors, Currency Rates, Commodity Prices, Yield Curve
- **Analysis Outputs**: Attribution Results, Factor Sensitivity, Behavioural Metrics, Sector-Macro Links
- **Final Output**: Performance Narrative

## Key Interaction Chains

1. **Performance Attribution** — Allocation + Selection + Interaction + Currency + Cash Flow Timing
2. **Cash Flow Timing Impact** — TWR vs MWR gap, quantified per investor action
3. **Macro Factor Sensitivities** — Correlations between portfolio returns and rate changes, inflation, FX, commodities
4. **Style & Factor Interactions** — Value/growth regime, size factor, quality, momentum
5. **Sector × Macro Links** — Resources↔commodities, Financials↔rates, Property↔yields
6. **Behavioural-Performance** — Switching costs, withdrawal timing, contribution benefits

## Tech Context

- **Demo**: React (JSX) with Tailwind CSS, designed for Claude.ai artifact rendering
- **Data Model**: Mermaid ER diagram
- **Target Stack** (future): FastAPI/Express backend, Supabase, async job queues

## South African Context

The demo is grounded in SA-specific data:
- SARB repo rate, ZAR/USD, JSE sectors
- Allan Gray-Orbis fund with MSCI World benchmark
- ASISA fund classifications
- SA regulatory frameworks

---

*Built as part of the InvestExtract ecosystem — AI-powered investment data tools for the South African financial advisory market.*
