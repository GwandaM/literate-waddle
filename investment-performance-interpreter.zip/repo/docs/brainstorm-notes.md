# Investment Performance Interpreter — Brainstorm Notes

## Design Session Output

This document captures the full brainstorm of metrics, correlations, and interactions that should be modelled in the Investment Performance Interpreter.

---

## The Four Data Pillars

**1. Market/Performance Data** — what actually happened to prices and returns
**2. Portfolio-Specific Info** — what's in the portfolio and how it's structured
**3. Macro & Micro Economic Factors** — the external environment
**4. Investor Actions** — what the investor did (cash flows, switches, etc.)

The magic is in how these four interact. Below is a walkthrough of each, the key metrics within them, and — most importantly — the correlations and interactions between them.

---

## Pillar 1: Market & Performance Metrics

These are the "what happened" numbers:

**Return metrics** — Total return, price return vs income return (dividends/coupons), time-weighted return (TWR) which strips out the effect of investor cash flows so you can judge the investment manager fairly, and money-weighted return (MWR, also called IRR) which includes cash flow timing and tells the investor what *they* actually earned.

**Risk metrics** — Volatility (how bumpy the ride was), maximum drawdown (the worst peak-to-trough fall), Sharpe ratio (return earned per unit of risk taken), Sortino ratio (like Sharpe but only penalises downside volatility), and tracking error (how much the portfolio deviated from its benchmark).

**Benchmark-relative metrics** — Alpha (excess return after adjusting for risk), beta (sensitivity to market movements), information ratio (alpha divided by tracking error — how consistently the manager outperformed), and active share (how different the portfolio looks from its benchmark).

---

## Pillar 2: Portfolio-Specific Information

This is the "what are we working with" layer:

**Composition** — Asset allocation (equities vs bonds vs cash vs alternatives), sector weights, geographic exposure, currency exposure, individual holding weights, and concentration (how much is in the top 10 holdings).

**Characteristics** — Weighted average P/E ratio, dividend yield, duration (for bonds — sensitivity to interest rate changes), credit quality distribution, and market cap breakdown (large vs mid vs small cap).

**Style factors** — Value vs growth tilt, momentum exposure, quality scores, and size factor exposure.

---

## Pillar 3: Macro & Micro Economic Factors

This is the "what was the environment" context:

**Macro** — GDP growth, inflation (CPI, PPI), interest rates and central bank policy (repo rate, Fed funds rate), unemployment, currency movements (ZAR/USD, etc.), commodity prices (especially relevant in SA with gold, platinum), yield curve shape (steep, flat, inverted), credit spreads, and market sentiment indicators (VIX, consumer confidence).

**Micro** — Company earnings surprises, revenue growth, margin changes, dividend announcements, corporate actions (mergers, rights issues), credit rating changes, and sector-specific regulatory changes.

---

## Pillar 4: Investor Actions

This is the "what did the investor do" layer:

**Cash flows** — Contributions (lump sum and recurring), withdrawals, timing of those flows relative to market movements, and net flow direction.

**Decisions** — Fund switches, rebalancing events, strategy changes, and mandate modifications.

**Behavioural indicators** — Frequency of switching, tendency to invest after market rises (performance chasing), tendency to withdraw after falls (panic selling), and holding period.

---

## Correlations & Interactions

This is where the tool becomes genuinely valuable. Here are the key relationships to model:

### A. Performance Attribution Decomposition

The classic framework breaks total return into layers:

**Asset allocation effect** — Did being overweight equities (vs the benchmark) help or hurt? This connects Pillar 2 (portfolio weights) to Pillar 1 (asset class returns). The formula compares the portfolio's allocation decisions against the benchmark's weights, multiplied by how each asset class performed.

**Security selection effect** — Within each asset class, did the manager pick winners? This isolates stock-picking skill from the allocation decision.

**Interaction effect** — The combined impact of being overweight in a sector *and* picking good stocks in that sector. This is often overlooked but can be significant.

**Currency effect** — For portfolios with offshore exposure, how much of the return came from rand weakness or strength vs actual underlying asset performance?

### B. Cash Flow Timing Impact

This is the gap between TWR and MWR, and it tells a powerful story:

**If MWR > TWR** — The investor's timing was good. They added money before good periods and withdrew before bad ones.

**If MWR < TWR** — The investor's timing hurt them. This is extremely common — studies show investors typically lose 1-2% per year through poor timing.

The tool should quantify this gap and attribute it to specific cash flow events. For example: "Your R500,000 contribution in March 2024 occurred two weeks before a 7% market rally, adding approximately R35,000 to your outcome."

### C. Macro Factor Sensitivities

These connect Pillar 3 to Pillar 1:

**Interest rate sensitivity** — How did repo rate changes correlate with portfolio returns? Bond-heavy portfolios will show strong inverse correlation. Property and high-dividend equity will also be sensitive.

**Inflation correlation** — Did the portfolio protect purchasing power? Inflation-linked bonds and commodities should show positive correlation with CPI.

**Currency impact** — For SA investors with offshore allocation, rand depreciation is often the single biggest driver of nominal returns in ZAR terms. The tool should decompose offshore returns into "underlying return in foreign currency" + "currency translation effect."

**GDP/earnings link** — Equity returns should, over time, correlate with earnings growth, which connects to GDP. The tool can show whether the portfolio's equity returns tracked or diverged from the earnings cycle.

### D. Style & Factor Interactions

These connect Pillar 2 (portfolio characteristics) to Pillar 1 (returns) through Pillar 3 (environment):

**Value vs growth regime** — In rising rate environments, value tends to outperform growth. The tool should flag: "The portfolio's growth tilt detracted 2.3% in a period when rising rates favoured value stocks."

**Small cap vs large cap** — Small caps tend to do well early in economic recoveries but struggle when liquidity tightens.

**Quality factor** — In volatile or uncertain markets, high-quality companies (strong balance sheets, stable earnings) tend to outperform. The tool can correlate VIX levels with the quality factor's contribution.

### E. Sector × Macro Interactions

Specific and very explainable:

**Resources sector ↔ commodity prices** — In SA, mining stocks correlate strongly with gold, platinum, and iron ore prices. The tool should directly link sector returns to commodity moves.

**Financials ↔ interest rates** — Banks benefit from steeper yield curves and higher rates (wider net interest margins).

**Property ↔ rates** — Listed property is very rate-sensitive; the tool should correlate REIT returns with bond yield movements.

**Consumer sectors ↔ inflation/employment** — Consumer discretionary stocks correlate with consumer confidence and employment data.

### F. Behavioural-Performance Interactions

This connects Pillar 4 to everything else:

**Switching cost analysis** — If the investor switched from Fund A to Fund B, what was the counterfactual? Show what would have happened if they stayed.

**Withdrawal timing cost** — Quantify the cost of selling units at a low point. "Your withdrawal of R200,000 in June 2024 crystallised a 12% loss that the fund subsequently recovered within 4 months."

**Contribution benefit analysis** — Show the compounding benefit of regular contributions, especially during drawdowns (buying more units at lower prices).

**Rebalancing impact** — Did systematic rebalancing (selling winners, buying losers) add or subtract value compared to a buy-and-hold approach?

### G. Risk-Return Interaction Metrics

These tie risk and return together to explain efficiency:

**Drawdown recovery analysis** — How long did it take to recover from each drawdown, and how did investor actions during the drawdown affect recovery time?

**Return per unit of drawdown** — Similar to Sharpe but using max drawdown instead of volatility, which is more intuitive for clients.

**Downside capture vs upside capture** — In months when the market fell, how much of that fall did the portfolio capture? In up months, how much of the upside? This directly explains whether the portfolio is defensive or aggressive in character.

---

## How These All Connect in a "Performance Story"

The interpreter would weave these together into narrative. For example:

> "Over the past 12 months, your portfolio returned 14.2% (MWR) vs the benchmark's 11.8%. The outperformance came primarily from three sources: being overweight offshore equities (+2.1%, driven largely by rand weakness of 8.3% against the dollar), strong stock selection in SA financials (+1.4%, as rising rates boosted bank earnings), and good contribution timing (+0.6%, as your February lump sum captured the subsequent rally). Partially offsetting this was the underweight to resources (-1.7%), which rallied on higher gold prices."

---

## Fund-Level Analysis (No Investor Actions)

For analysing a specific fund (e.g. Allan Gray-Orbis Global Equity Feeder Fund), the framework adapts:

- **Investor Actions pillar is removed** — all returns are TWR only
- **Attribution focuses on**: Stock selection, sector allocation, currency management, interaction effects, and fee impact
- **Additional fund-specific metrics**: Active share, concentration, P/E vs benchmark, turnover, style factor exposures
- **SA feeder fund layer**: USD returns + ZAR translation effect are separated

The Allan Gray-Orbis fund specifically demonstrates:
- Contrarian/value approach (18× P/E vs 28× benchmark)
- High active share with significant US underweight (43% vs 73%)
- Bottom-up stock picking as primary alpha source
- Refundable performance fee structure aligning interests
- 2025 context: tariff shocks, value headwinds, but idiosyncratic winners (QXO, Nintendo, PayPal)
